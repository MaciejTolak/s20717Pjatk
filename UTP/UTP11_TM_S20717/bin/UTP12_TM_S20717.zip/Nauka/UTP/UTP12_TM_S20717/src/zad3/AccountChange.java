package zad3;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class AccountChange implements PropertyChangeListener {


    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if((double)evt.getNewValue()<0)
            System.out.println("Value changed from: " + evt.getOldValue() + " to " + evt.getNewValue());
        else
            System.out.println("Value changed from: " + evt.getOldValue() + " to " + evt.getNewValue());
    }
}
