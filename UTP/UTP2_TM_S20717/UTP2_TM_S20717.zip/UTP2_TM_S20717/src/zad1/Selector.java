/**
 * @author Tolak Maciej S20717
 */

package zad1;


public interface Selector<T> { // Uwaga: interfejs musi być sparametrtyzowany

    boolean select(T zmienna);


}
